"""
Example Usage Script for Customer Journey System
"""

from customer_journey_system import CustomerJourneySystem

# Initialize the system
data_path = "data_all.xltx"
system = CustomerJourneySystem(data_path)

# STEP 1: Load & clean data
print("=" * 80)
print("Loading and cleaning data...")
print("=" * 80)
system.load_and_clean_data()

# STEP 2: Build journeys
print("\n" + "=" * 80)
print("Building journeys...")
print("=" * 80)
system.build_journeys()

# STEP 3: Top 5 paths by (country, solution)
print("\n" + "=" * 80)
print("Top 5 paths by Country & Solution")
print("=" * 80)
top_paths = system.top_5_paths_by_country_solution()

# STEP 4: Decision Tree model
print("\n" + "=" * 80)
print("Building Decision Tree model...")
print("=" * 80)
system.build_decision_tree_model()

# Pick a sample country & solution automatically
sample_country = system.cleaned_df[system.col_country].value_counts().index[0]
sample_solution = system.cleaned_df[system.col_solution].value_counts().index[0]

print("\nUsing sample account:")
print(f"  Country: {sample_country}")
print(f"  Solution: {sample_solution}")

# STEP 5: Required output when account info is added
print("\n" + "=" * 80)
print("ACCOUNT RECOMMENDATION")
print("=" * 80)
system.recommend_for_account(
    country=sample_country,
    solution=sample_solution
)

# STEP 6: Add action + recalculate
print("\n" + "=" * 80)
print("Adding action & recalculating")
print("=" * 80)

updated = system.add_action_and_recalculate(
    action="email",
    weight=1.5,
    country=sample_country,
    solution=sample_solution
)

print("\nUpdated Top 4 Actions:")
for k, v in updated.items():
    print(f"\n{k}:")
    for a, score in v:
        print(f"  - {a}: {score:.2f}")

print("\nDONE.")