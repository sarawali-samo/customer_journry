"""
Customer Journey Analysis System (HW)
- Clean data
- Group accounts by Country & Solution -> Top 5 paths
- Use DT to find importance of action types and predict Win/Loss
- Output:
  Top 4 actions by country
  Top 4 actions by solution
  Top 4 actions by country & solution
- Recalculate after adding weighted action
- Build best (shorter) trip for Win/Loss
"""

import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np

from collections import Counter, defaultdict
from typing import Dict, List, Tuple, Optional

from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report


class CustomerJourneySystem:
    def __init__(self, data_path: str):
        self.data_path = data_path
        self.df: Optional[pd.DataFrame] = None
        self.cleaned_df: Optional[pd.DataFrame] = None

        # journeys table (one row per journey)
        self.journeys_df: Optional[pd.DataFrame] = None

        # weights for action types
        self.action_weights: Dict[str, float] = {}

        # Decision Tree
        self.dt_model: Optional[DecisionTreeClassifier] = None
        self.feature_importance: Dict[str, float] = {}
        self.action_feature_names: List[str] = []  # action_* features
        self.target_col: str = "outcome"

        # detected column names
        self.col_account = None
        self.col_country = None
        self.col_solution = None
        self.col_action = None
        self.col_date = None
        self.col_stage = None
        self.col_opportunity = None

    # ---------------------------
    # Utilities
    # ---------------------------
    @staticmethod
    def _ensure_openpyxl():
        try:
            import openpyxl  # noqa: F401
        except ModuleNotFoundError:
            raise ModuleNotFoundError(
                "Missing dependency: 'openpyxl'. Install it using:\n"
                "  py -m pip install openpyxl\n"
                "or\n"
                "  python -m pip install openpyxl"
            )

    @staticmethod
    def _norm_str(s: str) -> str:
        return str(s).strip().lower()

    def _detect_columns(self):
        cols = list(self.cleaned_df.columns)
        low = {c: c.lower() for c in cols}

        def first_match(keywords):
            for c in cols:
                if any(k in low[c] for k in keywords):
                    return c
            return None

        self.col_account = first_match(["account"])
        self.col_country = first_match(["country", "region"])
        self.col_solution = first_match(["solution", "service", "serves", "type_of_service"])
        self.col_action = first_match(["types", "action", "activity_type", "touch", "event"])
        self.col_date = first_match(["date", "activity_date", "time", "timestamp"])
        self.col_stage = first_match(["stage", "opportunity_stage", "status", "result"])
        self.col_opportunity = first_match(["opportunity_id", "opp_id", "opportunity"])

        required = [self.col_account, self.col_country, self.col_solution, self.col_action]
        if any(x is None for x in required):
            raise ValueError(
                "I couldn't detect required columns. Required: account, country, solution, action(types).\n"
                f"Detected: account={self.col_account}, country={self.col_country}, "
                f"solution={self.col_solution}, action={self.col_action}"
            )

        if self.col_date is None:
            # If no date, we still can build paths without ordering (not ideal)
            print("WARNING: No date column detected. Journeys will not be ordered by time.")

        print("\nDetected columns:")
        print(f"  account: {self.col_account}")
        print(f"  country: {self.col_country}")
        print(f"  solution: {self.col_solution}")
        print(f"  action(types): {self.col_action}")
        print(f"  date: {self.col_date}")
        print(f"  opportunity_id: {self.col_opportunity}")
        print(f"  stage/status: {self.col_stage}")

    # ---------------------------
    # 1) Load & Clean data
    # ---------------------------
    def load_and_clean_data(self) -> pd.DataFrame:
        print("STEP 1: Loading and cleaning data...")

        self._ensure_openpyxl()
        self.df = pd.read_excel(self.data_path, engine="openpyxl")
        print(f"Original data shape: {self.df.shape}")

        df = self.df.copy()

        # Standardize column names (keep original but safer)
        # Clean string columns
        for c in df.select_dtypes(include=["object"]).columns:
            df[c] = df[c].astype(str).str.strip()

        # Drop duplicates
        before = len(df)
        df = df.drop_duplicates()
        print(f"Removed duplicates: {before - len(df)}")

        # Detect columns on cleaned copy
        self.cleaned_df = df
        self._detect_columns()

        # Normalize key string columns
        for c in [self.col_country, self.col_solution, self.col_action]:
            self.cleaned_df[c] = self.cleaned_df[c].apply(self._norm_str)

        # Parse date if exists
        if self.col_date:
            self.cleaned_df[self.col_date] = pd.to_datetime(self.cleaned_df[self.col_date], errors="coerce")

        # Fill missing values
        # key columns: drop rows missing required fields
        self.cleaned_df = self.cleaned_df.dropna(subset=[self.col_account, self.col_country, self.col_solution, self.col_action])

        # Outcome column
        self.cleaned_df[self.target_col] = self._derive_outcome(self.cleaned_df)

        # Keep only rows with known outcome for DT training (journeys still can be built)
        print(f"Known outcomes count:\n{self.cleaned_df[self.target_col].value_counts(dropna=False)}")

        print(f"Cleaned data shape: {self.cleaned_df.shape}")
        print(f"Columns: {list(self.cleaned_df.columns)}")
        return self.cleaned_df

    def _derive_outcome(self, df: pd.DataFrame) -> pd.Series:
        """
        Create outcome (win/loss/unknown).
        Uses stage/status if available, otherwise heuristic:
        - if opportunity_stage contains won/win/success -> win
        - if contains lost/lose/fail -> loss
        - else unknown
        """
        if self.col_stage and self.col_stage in df.columns:
            stage = df[self.col_stage].astype(str).str.lower()
            win_mask = stage.str.contains("won|win|success|closed won|completed", na=False)
            loss_mask = stage.str.contains("lost|lose|failure|closed lost|cancel", na=False)

            out = pd.Series(["unknown"] * len(df), index=df.index)
            out[win_mask] = "win"
            out[loss_mask] = "loss"
            return out

        # fallback: no stage column
        return pd.Series(["unknown"] * len(df), index=df.index)

    # ---------------------------
    # 2) Build journeys and paths
    # ---------------------------
    def build_journeys(self) -> pd.DataFrame:
        """
        Build one journey per (account_id, opportunity_id if exists else account_id)
        Journey path = ordered list of actions (types) by activity_date if available
        """
        if self.cleaned_df is None:
            raise RuntimeError("Call load_and_clean_data() first.")

        print("\nSTEP 2: Building journeys (paths)...")

        key_cols = [self.col_account]
        if self.col_opportunity:
            key_cols.append(self.col_opportunity)

        # ordering
        df = self.cleaned_df.copy()
        if self.col_date:
            df = df.sort_values(self.col_date)

        # aggregate actions into list per journey
        grp = df.groupby(key_cols, dropna=False)

        journeys = []
        for key, g in grp:
            country = g[self.col_country].iloc[0]
            solution = g[self.col_solution].iloc[0]
            outcome = g[self.target_col].iloc[-1]  # last known status in journey
            actions = g[self.col_action].tolist()

            # remove empty
            actions = [a for a in actions if pd.notna(a) and str(a).strip() != ""]
            if not actions:
                continue

            path = " -> ".join(actions)
            journeys.append({
                "journey_key": key,
                "country": country,
                "solution": solution,
                "outcome": outcome,
                "path": path,
                "path_len": len(actions),
                "actions": actions
            })

        self.journeys_df = pd.DataFrame(journeys)
        print(f"Journeys built: {len(self.journeys_df)}")
        return self.journeys_df

    def top_5_paths_by_country_solution(self) -> Dict[Tuple[str, str], List[Tuple[str, int]]]:
        """
        Group by (country, solution), then return top 5 paths by frequency (all outcomes).
        """
        if self.journeys_df is None:
            raise RuntimeError("Call build_journeys() first.")

        print("\nSTEP 3: Top 5 paths per (Country, Solution)...")
        result = {}
        for (country, solution), g in self.journeys_df.groupby(["country", "solution"]):
            cnt = Counter(g["path"])
            result[(country, solution)] = cnt.most_common(5)

        # print sample groups
        shown = 0
        for k, v in result.items():
            print(f"\nGroup: {k}  (showing up to 5)")
            for p, c in v:
                print(f"  {c}  |  {p[:140]}")
            shown += 1
            if shown >= 5:
                break

        return result

    def best_shortest_trip(self, country: str, solution: str, outcome: str = "win") -> Optional[str]:
        """
        Best & shorter journey:
        - filter journeys for (country, solution, outcome)
        - choose the shortest path_len among top frequent paths (tie -> highest frequency)
        """
        if self.journeys_df is None:
            raise RuntimeError("Call build_journeys() first.")

        country = self._norm_str(country)
        solution = self._norm_str(solution)
        outcome = self._norm_str(outcome)

        g = self.journeys_df[
            (self.journeys_df["country"] == country) &
            (self.journeys_df["solution"] == solution) &
            (self.journeys_df["outcome"] == outcome)
        ]

        if g.empty:
            return None

        # count paths
        cnt = Counter(g["path"])
        # compute shortest length per path
        lens = g.groupby("path")["path_len"].min().to_dict()

        # rank: shortest length first, then frequency desc
        ranked = sorted(cnt.items(), key=lambda x: (lens.get(x[0], 10**9), -x[1]))
        return ranked[0][0] if ranked else None

    # ---------------------------
    # 3) Decision Tree on action-type features
    # ---------------------------
    def build_decision_tree_model(self) -> Dict:
        """
        Train DT to predict win/loss using action-type count features + country/solution.
        Prints:
        - top important features (especially action_*).
        - classification report (optional but useful).
        """
        if self.journeys_df is None:
            raise RuntimeError("Call build_journeys() first.")

        print("\nSTEP 4: Building Decision Tree model (Win/Loss)...")

        # Use only win/loss journeys
        data = self.journeys_df[self.journeys_df["outcome"].isin(["win", "loss"])].copy()
        if data.empty or data["outcome"].nunique() < 2:
            print("WARNING: Not enough win/loss data to train DT. Check opportunity_stage values.")
            return {"model": None, "feature_importance": {}}

        # Build action count features
        all_actions = sorted({a for acts in data["actions"] for a in acts})
        self.action_feature_names = [f"action_{a}" for a in all_actions]

        X_rows = []
        for _, row in data.iterrows():
            feats = {}

            # action counts
            counts = Counter(row["actions"])
            for a in all_actions:
                feats[f"action_{a}"] = counts.get(a, 0)

            # add group info (country/solution) as categorical codes
            feats["country"] = row["country"]
            feats["solution"] = row["solution"]
            feats["total_actions"] = row["path_len"]

            X_rows.append(feats)

        X = pd.DataFrame(X_rows)

        # Encode country/solution
        for c in ["country", "solution"]:
            X[c] = X[c].astype(str)
            X[c] = pd.factorize(X[c])[0]

        y = (data["outcome"] == "win").astype(int)  # win=1, loss=0

        # Train/test split (for report)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )

        self.dt_model = DecisionTreeClassifier(
            max_depth=8,
            min_samples_split=20,
            min_samples_leaf=10,
            random_state=42
        )

        self.dt_model.fit(X_train, y_train)

        # importance
        self.feature_importance = dict(zip(X.columns, self.dt_model.feature_importances_))
        sorted_imp = sorted(self.feature_importance.items(), key=lambda x: x[1], reverse=True)

        print("\nTop 15 Most Important Features (DT):")
        for f, v in sorted_imp[:15]:
            print(f"  {f}: {v:.4f}")

        # Focus: action features only (the "next top four types of actions")
        action_only = [(f, v) for f, v in sorted_imp if f.startswith("action_")]
        print("\nNext Top 4 Action Types from DT importance:")
        for f, v in action_only[:4]:
            print(f"  {f.replace('action_', '')}: {v:.4f}")

        # model quality (helpful for HW)
        y_pred = self.dt_model.predict(X_test)
        print("\nDT Classification Report (Win=1, Loss=0):")
        print(classification_report(y_test, y_pred, digits=4))

        return {
            "model": self.dt_model,
            "feature_importance": self.feature_importance
        }

    # ---------------------------
    # 4) Top actions (weighted)
    # ---------------------------
    def _apply_weights(self, counts: Counter) -> Counter:
        weighted = Counter()
        for action, c in counts.items():
            w = self.action_weights.get(self._norm_str(action), 1.0)
            weighted[action] = c * w
        return weighted

    def get_top_actions(
        self,
        country: Optional[str] = None,
        solution: Optional[str] = None,
        n_actions: int = 4
    ) -> Dict[str, List[Tuple[str, float]]]:
        """
        Required outputs:
        - Top 4 actions by country
        - Top 4 actions by solution
        - Top 4 actions by country and solution
        """
        if self.cleaned_df is None:
            raise RuntimeError("Call load_and_clean_data() first.")

        df = self.cleaned_df.copy()
        action_col = self.col_action

        res = {}

        if country:
            c = self._norm_str(country)
            g = df[df[self.col_country] == c]
            cnt = Counter(g[action_col])
            res["by_country"] = self._apply_weights(cnt).most_common(n_actions)

        if solution:
            s = self._norm_str(solution)
            g = df[df[self.col_solution] == s]
            cnt = Counter(g[action_col])
            res["by_solution"] = self._apply_weights(cnt).most_common(n_actions)

        if country and solution:
            c = self._norm_str(country)
            s = self._norm_str(solution)
            g = df[(df[self.col_country] == c) & (df[self.col_solution] == s)]
            cnt = Counter(g[action_col])
            res["by_country_and_solution"] = self._apply_weights(cnt).most_common(n_actions)

        return res

    def add_action_and_recalculate(self, action: str, weight: float = 1.5,
                                   country: Optional[str] = None, solution: Optional[str] = None) -> Dict:
        """
        When user adds an action -> update weight and recalc Top 4 actions.
        """
        a = self._norm_str(action)
        self.action_weights[a] = float(weight)
        print(f"\nUpdated weight: action='{a}' weight={weight}")
        return self.get_top_actions(country=country, solution=solution, n_actions=4)

    # ---------------------------
    # 5) Full required output when account info is added
    # ---------------------------
    def recommend_for_account(self, country: str, solution: str) -> Dict:
        """
        When account info added, print required outputs:
        - Top 4 actions by country
        - Top 4 actions by solution
        - Top 4 actions by country and solution
        - Best & shorter trip for win/loss
        - DT predicted win probability (if model exists)
        """
        country_n = self._norm_str(country)
        solution_n = self._norm_str(solution)

        print("\n" + "=" * 80)
        print("ACCOUNT RECOMMENDATION OUTPUT")
        print("=" * 80)
        print(f"Input: country='{country_n}', solution='{solution_n}'")

        actions = self.get_top_actions(country=country_n, solution=solution_n, n_actions=4)

        print("\nTop 4 actions by country:")
        for a, v in actions.get("by_country", []):
            print(f"  - {a}: {v:.2f}")

        print("\nTop 4 actions by solution:")
        for a, v in actions.get("by_solution", []):
            print(f"  - {a}: {v:.2f}")

        print("\nTop 4 actions by country and solution:")
        for a, v in actions.get("by_country_and_solution", []):
            print(f"  - {a}: {v:.2f}")

        best_win = self.best_shortest_trip(country_n, solution_n, outcome="win")
        best_loss = self.best_shortest_trip(country_n, solution_n, outcome="loss")

        print("\nBest & Shorter Journey to WIN:")
        print(f"  {best_win if best_win else 'No win journey found for this group.'}")

        print("\nBest & Shorter Journey leading to LOSS (to avoid):")
        print(f"  {best_loss if best_loss else 'No loss journey found for this group.'}")

        pred = None
        if self.dt_model is not None:
            pred = self._predict_win_probability(country_n, solution_n)
            if pred is not None:
                print(f"\nDT Predicted Win Probability (based on group patterns): {pred:.2%}")

        out = {
            "top_actions": actions,
            "best_win_trip": best_win,
            "best_loss_trip": best_loss,
            "dt_win_probability": pred
        }
        print("=" * 80)
        return out

    def _predict_win_probability(self, country: str, solution: str) -> Optional[float]:
        """
        Predict win probability for the group using a simple "average action profile" of that group.
        (This is acceptable for HW as a practical approximation.)
        """
        if self.dt_model is None or self.journeys_df is None:
            return None

        data = self.journeys_df[
            (self.journeys_df["country"] == country) &
            (self.journeys_df["solution"] == solution) &
            (self.journeys_df["outcome"].isin(["win", "loss"]))
        ]
        if data.empty:
            return None

        # build mean action-count vector for this group
        all_actions = [f.replace("action_", "") for f in self.action_feature_names]
        counts_sum = Counter()
        total = 0
        for acts in data["actions"]:
            counts_sum.update(Counter(acts))
            total += 1

        row = {}
        for a in all_actions:
            row[f"action_{a}"] = counts_sum.get(a, 0) / max(total, 1)

        # encode country/solution same way as training used (factorize isn't stored),
        # so we approximate by 0 (model mainly relies on action features).
        row["country"] = 0
        row["solution"] = 0
        row["total_actions"] = data["path_len"].mean()

        X_pred = pd.DataFrame([row])
        proba = self.dt_model.predict_proba(X_pred)[0][1]  # class 1 = win
        return float(proba)


def main():
    data_path = "data_all.xltx"
    system = CustomerJourneySystem(data_path)

    # 1) Load & clean
    system.load_and_clean_data()

    # 2) Build journeys
    system.build_journeys()

    # 3) Top 5 paths per (country, solution)
    system.top_5_paths_by_country_solution()

    # 4) Decision Tree (win/loss)
    system.build_decision_tree_model()

    # 5) Demo: pick a sample (most frequent country/solution)
    # Use your own input here if you want
    sample_country = system.cleaned_df[system.col_country].value_counts().index[0]
    sample_solution = system.cleaned_df[system.col_solution].value_counts().index[0]

    # Required output when account information is added
    system.recommend_for_account(country=sample_country, solution=sample_solution)

    # 6) When user adds an action -> recalc with weights (required)
    print("\n" + "=" * 80)
    print("ADDING ACTION WITH WEIGHT & RECALCULATING (DEMO)")
    print("=" * 80)
    updated = system.add_action_and_recalculate(
        action="email", weight=1.5,
        country=sample_country, solution=sample_solution
    )
    print("\nRecalculated Top 4 (after weights):")
    for k, v in updated.items():
        print(f"\n{k}:")
        for a, score in v:
            printnd = f"{score:.2f}" if isinstance(score, (int, float)) else str(score)
            print(f"  - {a}: {score:.2f}")

    print("\nDONE.")


if __name__ == "__main__":
    main()
